# Kizz Mïdê ÇRÜÏSÊ Creative Academy

A lightweight Flask + SQLite starter project for a creative training website. It includes a public application form and a private admin dashboard. Payments are intentionally not integrated.

## Requirements

- Windows 10
- Python 3.10 or newer (Python 3.11 or 3.12 recommended)
- Internet connection for the one-time package installation
- A browser such as Chrome

## 1. Install Python

Install Python from https://www.python.org/downloads/windows/ . During installation, tick **Add Python to PATH**. Open Command Prompt and check:

```bat
py --version
```

If `py` is not recognized, reopen Command Prompt after installation or use the Python launcher installed on your computer.

## 2. Open the project folder

Extract the project ZIP. Open the `kizz_mide_creative` folder. Click the address bar in File Explorer, type `cmd`, and press Enter. A Command Prompt should open in the project folder.

## 3. Create a virtual environment

```bat
py -m venv .venv
.venv\Scripts\activate
py -m pip install --upgrade pip
pip install -r requirements.txt
```

If activation is blocked in PowerShell, use **Command Prompt** as described above. In Command Prompt, the activation command shown here should work.

## 4. Set up secure admin credentials

Do not use a blank password or publish your admin password.

First, create a password hash. In Command Prompt, with the virtual environment active, run:

```bat
py -c "from werkzeug.security import generate_password_hash; print(generate_password_hash(input('Choose an admin password: ')))"
```

Type a strong unique password when prompted and copy the resulting hash. Keep it private.

Generate a secret key:

```bat
py -c "import secrets; print(secrets.token_urlsafe(48))"
```

Copy the generated key. Now set the four environment values in the same Command Prompt window. Replace the example values with your own; keep the hash inside double quotes.

```bat
set SECRET_KEY=PASTE_YOUR_GENERATED_SECRET_KEY
set ADMIN_USERNAME=your_admin_username
set ADMIN_PASSWORD_HASH=PASTE_YOUR_PASSWORD_HASH
set PRO_FEE_NGN=25000
```

These `set` values apply only to the current Command Prompt window. If you close it, repeat them when you reopen the project. Never commit these values to a public repository.

## 5. Run the website

```bat
py app.py
```

Open these addresses in your browser:

- Public website: http://127.0.0.1:5000
- Admin login: http://127.0.0.1:5000/admin/login

Log in using the username and password you configured. Submit a test application through the public form, then refresh the admin dashboard. The application should appear there. The SQLite database file `applications.db` is created in the project folder.

Stop the local server with **Ctrl + C** in Command Prompt.

## 6. Change the sample Pro fee

The example fee is ₦25,000. To change it for this local run, set a different value before starting:

```bat
set PRO_FEE_NGN=30000
```

Also update the display value in `static/main.js` (`const proFee = 25000`) to match. This is only a displayed sample price; no payments are collected.

## What this starter version does

- Displays the black-and-gold creative academy site.
- Accepts applications for Video Editing, Photo Editing & Graphic Design, and Web Design.
- Saves submitted applications in SQLite.
- Provides an admin login and application dashboard.
- Lets the admin search and filter applications and update their status.
- Uses password hashing, CSRF tokens, parameterized SQL, basic security headers, and an HTTP-only session cookie.

## Important limitations before public launch

This is a learning/starter application, not a fully hardened production service. Before making it public:

1. Deploy behind HTTPS and set `COOKIE_SECURE=1`.
2. Use a production WSGI server and a reputable hosting provider; do not expose Flask's development server directly to the internet.
3. Add login rate limiting, stronger operational monitoring, automated database backups, and a plan for database migrations.
4. Configure secrets through the hosting provider's secret/environment settings, not in source code.
5. Add a privacy notice and retention policy. Protect applicant data and restrict access to the admin dashboard.
6. If the site becomes busy or needs multiple app instances, move from SQLite to a managed database such as PostgreSQL.
7. Payments are not implemented. When adding Paystack or Flutterwave, create payment sessions on the backend and verify payment webhooks/signatures on the server. Never trust a browser-only “payment successful” message.
8. Add an email verification or notification flow if required, and test all forms on the live deployment.

## Troubleshooting

- **`py` not recognized:** reinstall Python with “Add Python to PATH” enabled and reopen Command Prompt.
- **`No module named flask`:** activate `.venv` and run `pip install -r requirements.txt`.
- **Missing SECRET_KEY or admin credentials:** run the environment setup commands in step 4 in the same terminal before `py app.py`.
- **Port 5000 is busy:** change the final line of `app.py` from `port=5000` to `port=5001`, then open `http://127.0.0.1:5001`.
- **Admin login fails:** use the exact username and the original password that you hashed. `ADMIN_PASSWORD_HASH` must contain the generated hash, not the plain password.
- **Lost database:** applications are stored in `applications.db`. Back up this file while the app is stopped.
