import os
import hmac
import secrets
import sqlite3
from functools import wraps
from pathlib import Path

from flask import (
    Flask, render_template, request, redirect, url_for, session,
    flash, abort, jsonify
)
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = Path(__file__).resolve().parent
DATABASE = BASE_DIR / "applications.db"

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "")
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
# Set COOKIE_SECURE=1 only after deploying behind HTTPS.
app.config["SESSION_COOKIE_SECURE"] = os.environ.get("COOKIE_SECURE", "0") == "1"
app.config["MAX_CONTENT_LENGTH"] = 1 * 1024 * 1024  # 1 MB requests

ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "")
ADMIN_PASSWORD_HASH = os.environ.get("ADMIN_PASSWORD_HASH", "")
PRO_FEE_NGN = int(os.environ.get("PRO_FEE_NGN", "25000"))

if not app.config["SECRET_KEY"]:
    raise RuntimeError(
        "SECRET_KEY is missing. Follow README.md to set SECRET_KEY in your Command Prompt before starting the app."
    )
if not ADMIN_USERNAME or not ADMIN_PASSWORD_HASH:
    raise RuntimeError(
        "Admin credentials are missing. Follow README.md to set ADMIN_USERNAME "
        "and ADMIN_PASSWORD_HASH in your environment."
    )

SKILLS = [
    "Video Editing",
    "Photo Editing & Graphic Design",
    "Web Design",
]

STATUSES = {"New", "Reviewing", "Approved", "Rejected"}


def connect_db():
    connection = sqlite3.connect(DATABASE)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def init_db():
    with connect_db() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS applications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                full_name TEXT NOT NULL,
                email TEXT NOT NULL,
                phone TEXT NOT NULL,
                skill TEXT NOT NULL,
                level TEXT NOT NULL,
                experience TEXT NOT NULL,
                goals TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL DEFAULT 'New',
                created_at TEXT NOT NULL DEFAULT (datetime('now')),
                updated_at TEXT NOT NULL DEFAULT (datetime('now'))
            )
        """)
        db.execute("CREATE INDEX IF NOT EXISTS idx_applications_created ON applications(created_at)")
        db.execute("CREATE INDEX IF NOT EXISTS idx_applications_status ON applications(status)")


def csrf_token():
    token = session.get("_csrf_token")
    if not token:
        token = secrets.token_urlsafe(32)
        session["_csrf_token"] = token
    return token


app.jinja_env.globals["csrf_token"] = csrf_token


def verify_csrf():
    sent = request.form.get("_csrf_token", "")
    expected = session.get("_csrf_token", "")
    if not sent or not expected or not hmac.compare_digest(sent, expected):
        abort(400, description="Your form expired or could not be verified. Go back and try again.")


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("admin_logged_in"):
            return redirect(url_for("admin_login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


@app.after_request
def security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; style-src 'self' 'unsafe-inline'; "
        "script-src 'self'; img-src 'self' data:; form-action 'self'; "
        "base-uri 'self'; frame-ancestors 'none'"
    )
    return response


@app.route("/")
def home():
    return render_template("index.html", pro_fee=PRO_FEE_NGN)


@app.route("/apply", methods=["POST"])
def apply():
    verify_csrf()
    full_name = request.form.get("full_name", "").strip()
    email = request.form.get("email", "").strip().lower()
    phone = request.form.get("phone", "").strip()
    skill = request.form.get("skill", "").strip()
    level = request.form.get("level", "").strip()
    experience = request.form.get("experience", "Complete beginner").strip()
    goals = request.form.get("goals", "").strip()

    errors = []
    if not (2 <= len(full_name) <= 100):
        errors.append("Enter your full name (2–100 characters).")
    if len(email) > 254 or "@" not in email or "." not in email.rsplit("@", 1)[-1]:
        errors.append("Enter a valid email address.")
    if not (7 <= len(phone) <= 30):
        errors.append("Enter a valid WhatsApp or phone number.")
    if skill not in SKILLS:
        errors.append("Choose one of the available skills.")
    if level not in {"Beginner", "Pro"}:
        errors.append("Choose Beginner or Pro.")
    if experience not in {"Complete beginner", "Basic knowledge", "Intermediate"}:
        errors.append("Choose an experience level.")
    if len(goals) > 1000:
        errors.append("Your learning goals must be 1,000 characters or fewer.")

    if errors:
        for error in errors:
            flash(error, "error")
        return redirect(url_for("home") + "#apply")

    with connect_db() as db:
        db.execute("""
            INSERT INTO applications
            (full_name, email, phone, skill, level, experience, goals)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (full_name, email, phone, skill, level, experience, goals))

    flash("Application received! This demo has saved your application. Payments are not enabled yet.", "success")
    return redirect(url_for("home") + "#apply")


@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if session.get("admin_logged_in"):
        return redirect(url_for("admin_dashboard"))

    if request.method == "POST":
        verify_csrf()
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        # Constant-time username comparison and Werkzeug's password hash checker.
        username_ok = hmac.compare_digest(username, ADMIN_USERNAME)
        password_ok = check_password_hash(ADMIN_PASSWORD_HASH, password)
        if username_ok and password_ok:
            session.clear()
            session["admin_logged_in"] = True
            session["admin_username"] = ADMIN_USERNAME
            session["_csrf_token"] = secrets.token_urlsafe(32)
            return redirect(url_for("admin_dashboard"))
        flash("Login details were not correct.", "error")

    return render_template("login.html")


@app.route("/admin")
@admin_required
def admin_dashboard():
    status_filter = request.args.get("status", "").strip()
    search = request.args.get("q", "").strip()[:100]
    query = "SELECT * FROM applications WHERE 1=1"
    params = []

    if status_filter in STATUSES:
        query += " AND status = ?"
        params.append(status_filter)
    if search:
        like = f"%{search}%"
        query += " AND (full_name LIKE ? OR email LIKE ? OR phone LIKE ?)"
        params.extend([like, like, like])

    query += " ORDER BY created_at DESC, id DESC"
    with connect_db() as db:
        applications = db.execute(query, params).fetchall()
        total = db.execute("SELECT COUNT(*) FROM applications").fetchone()[0]
        new_count = db.execute("SELECT COUNT(*) FROM applications WHERE status='New'").fetchone()[0]
        approved_count = db.execute("SELECT COUNT(*) FROM applications WHERE status='Approved'").fetchone()[0]

    return render_template(
        "admin.html",
        applications=applications,
        total=total,
        new_count=new_count,
        approved_count=approved_count,
        status_filter=status_filter,
        search=search,
        statuses=sorted(STATUSES),
    )


@app.route("/admin/application/<int:application_id>/status", methods=["POST"])
@admin_required
def update_status(application_id):
    verify_csrf()
    status = request.form.get("status", "").strip()
    if status not in STATUSES:
        abort(400, description="Invalid application status.")
    with connect_db() as db:
        result = db.execute(
            "UPDATE applications SET status=?, updated_at=datetime('now') WHERE id=?",
            (status, application_id)
        )
        if result.rowcount == 0:
            abort(404)
    flash(f"Application #{application_id} updated to {status}.", "success")
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/logout", methods=["POST"])
@admin_required
def admin_logout():
    verify_csrf()
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("admin_login"))


@app.errorhandler(400)
def bad_request(error):
    return render_template("error.html", code=400, message=getattr(error, "description", "Bad request.")), 400


@app.errorhandler(404)
def not_found(error):
    return render_template("error.html", code=404, message="The page or application was not found."), 404


if __name__ == "__main__":
    init_db()
    # Local development only. Do not use Flask's development server for production.
    app.run(host="127.0.0.1", port=5000, debug=False)
