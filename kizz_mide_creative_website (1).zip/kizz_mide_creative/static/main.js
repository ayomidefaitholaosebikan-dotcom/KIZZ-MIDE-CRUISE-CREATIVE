document.addEventListener("DOMContentLoaded", () => {
  const year = document.getElementById("year");
  if (year) year.textContent = new Date().getFullYear();

  const skill = document.getElementById("skill");
  const level = document.getElementById("level");
  const fee = document.getElementById("fee-display");
  const form = document.getElementById("application-form");
  const proFee = Number(form?.dataset.proFee || 25000);

  function updateFee() {
    if (!fee || !level) return;
    if (!level.value) fee.textContent = "Choose a program to see the fee.";
    else if (level.value === "Beginner") fee.textContent = "Application fee: Free";
    else fee.textContent = "Sample Pro training fee: ₦" + proFee.toLocaleString("en-NG") + " — payment is not enabled yet.";
  }

  if (level) level.addEventListener("change", updateFee);

  document.querySelectorAll(".pick-skill").forEach(button => {
    button.addEventListener("click", () => {
      if (skill) skill.value = button.dataset.skill;
      document.getElementById("apply")?.scrollIntoView({ behavior: "smooth" });
    });
  });

  document.querySelectorAll(".choose-level").forEach(button => {
    button.addEventListener("click", () => {
      if (level) {
        level.value = button.dataset.level;
        updateFee();
      }
      document.getElementById("apply")?.scrollIntoView({ behavior: "smooth" });
    });
  });
});
